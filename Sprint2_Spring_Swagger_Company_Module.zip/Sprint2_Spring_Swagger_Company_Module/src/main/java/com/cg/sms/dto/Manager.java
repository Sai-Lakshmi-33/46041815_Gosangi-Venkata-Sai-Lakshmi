package com.cg.sms.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="manager")
public class Manager 
{
	@Id
	@GeneratedValue
	private int managerId;
	private String managerName;
	private String email;
	private String mobileNo;	
	
	public Manager() {
		
	}

	public Manager(int managerId, String managerName, String email, String mobileNo) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + ", managerName=" + managerName + ", email=" + email + ", mobileNo="
				+ mobileNo + "]";
	}
}
