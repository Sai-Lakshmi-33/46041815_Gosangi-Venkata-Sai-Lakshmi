package com.cg.sms.service;

import java.util.List;

import com.cg.sms.dto.Company;
import com.cg.sms.exceptions.InvalidOperation;


public interface ICompanyService 
{
	//------------------------ Company Module--------------------------
	  /******************************************************************************************************
		- Function Name	    :	addCompanyInfo(Company info)
		- Input Parameters	:	Company info
		- Return Type		:	Company
		- Throws			:   InvalidOperation
		- Author			:	Sai Lakshmi
		- Creation Date	    :	12/11/2020
		- Description		:	This method add records to database and returns company
	 ********************************************************************************************************/
	
	public Company addCompanyInfo(Company info) throws InvalidOperation;
	
	//------------------------ Company Module ----------------------------------------------------------
	  /***************************************************************************************************
		- Function Name	    :	 getAllCompanyInfo()
		- Input Parameters  :	 -------------
		- Return Type		:	 List<Company>
		- Author			:	 Sai Lakshmi
		- Creation Date	    :	 12/11/2020
		- Description		:	 This method returns all company details
	  ****************************************************************************************************/

	public List<Company> getAllCompanyInfo();
	
	//------------------------ Company Module ----------------------------------------------------------
	   /***************************************************************************************************
		 - Function Name	  :	  getCompanyDetails(int companyId)
		 - Input Parameters   :	  int companyId
		 - Return Type		  :	  Company
		 - Author			  :	  Sai Lakshmi
		 - Creation Date	  :	  12/11/2020
		 - Description		  :	  This method returns company details based on id
	  ****************************************************************************************************/

	public Company getCompanyDetails(int companyId);
	
	//------------------------ Company Module ----------------------------------------------------------
    /***************************************************************************************************
	    - Function Name	    :	updateCompanyInfo(Company info)
	    - Input Parameters	:	Company info
	    - Return Type		:	Company
	    - Throws			:  	InvalidOperation
	    - Author			:	Sai Lakshmi
	    - Creation Date	    :	12/11/2020
	    - Description		:	This method update records in database and  returns company
	  ****************************************************************************************************/
	
	public Company updateCompanyInfo(Company info) throws InvalidOperation;
	
	//------------------------ Company Module ----------------------------------------------------------
    /***************************************************************************************************
	  	- Function Name	      :	  deleteCompanyInfo(int companyId)
	    - Input Parameters    :	  int companyId
	  	- Return Type		  :	  Company
	  	- Author			  :	  Sai Lakshmi
	  	- Creation Date	      :	  12/11/2020
	  	- Description		  :	  This method deletes company record in database and returns company details
	 ****************************************************************************************************/

	public Company deleteCompanyInfo(int companyId);

}
