package com.cg.sms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.sms.dto.Company;
import com.cg.sms.exceptions.InvalidOperation;
import com.cg.sms.service.CompanyService;

@Controller
@RequestMapping("/company")
public class CompanyController
{
	Logger logger = LoggerFactory.getLogger(CompanyController.class);
	
	@Autowired
	CompanyService compService;
	
	@PostMapping("/")
	public @ResponseBody ResponseEntity<Company> addCompanyInfo(@RequestBody Company info) 
	{
		logger.info("add company info initialized");
		try 
		{
			return new ResponseEntity<>(compService.addCompanyInfo(info),HttpStatus.OK);
		} 
		catch (InvalidOperation e)
		{
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/")
	public @ResponseBody List<Company> getAllCompanyInfo() 
	{ 
		logger.info("get all company info initialized");
		return compService.getAllCompanyInfo();
	}
	
	@GetMapping("/{companyId}")
	public @ResponseBody Company getCompanyDetails(@PathVariable int companyId)
	{
		logger.info("get company details based on id initialized");
		return compService.getCompanyDetails(companyId);
	}
	
	@PutMapping("/")
	public @ResponseBody ResponseEntity<Company> updateCompanyInfo(@RequestBody Company info)
	{
		logger.info("update company info initialized");
		try 
		{
			return new ResponseEntity<>(compService.updateCompanyInfo(info),HttpStatus.OK);
		} 
		catch (InvalidOperation e)
		{
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping("/{companyId}")
	public @ResponseBody Company deleteCompanyInfo(@PathVariable int companyId) 
	{
		logger.info("delete company info initialized");
		return compService.deleteCompanyInfo(companyId);
	}
	
}