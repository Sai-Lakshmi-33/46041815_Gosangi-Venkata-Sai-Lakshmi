package com.cg.sms.validations;

public class Validations
{
	public static boolean name(String name)
	{
		String pattern="[A-Za-z]{3,}";
		if(name.matches(pattern))
			return true;
		else
			return false;
	}
	
	public static boolean email(String email)
	{
		String pattern="[A-Za-z]{1}[A-Za-z0-9#$%^&*]+[@][A-Za-z]+[.][A-Za-z]+";
		if(email.matches(pattern))
			return true;
		else
			return false;
	}
	
	public static boolean mobileNo(String mobileNo)
	{
		String pattern="[6-9]{1}[0-9]{9}";
		if(mobileNo.matches(pattern))
			return true;
		else
			return false;
	}
}
