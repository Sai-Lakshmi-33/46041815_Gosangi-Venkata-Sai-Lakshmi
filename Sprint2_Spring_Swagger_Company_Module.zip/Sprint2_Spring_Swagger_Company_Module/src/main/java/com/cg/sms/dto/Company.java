package com.cg.sms.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="company")
public class Company 
{
	@Id
	@GeneratedValue
	private int companyId;
	private String companyName;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="manager_id")
	private Manager manager;
	private int noOfStocks;
	private double stockPrice;
	private double percentageChange;	
	
	public Company() {
		
	} 

	public Company(int companyId, String companyName, Manager manager, int noOfStocks, double stockPrice,
			double percentageChange) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.manager = manager;
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
		this.percentageChange = percentageChange;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Manager getManager() {
		return manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}

	public int getNoOfStocks() {
		return noOfStocks;
	}

	public void setNoOfStocks(int noOfStocks) {
		this.noOfStocks = noOfStocks;
	}

	public double getStockPrice() {
		return stockPrice;
	}

	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}

	public double getPercentageChange() {
		return percentageChange;
	}

	public void setPercentageChange(double percentageChange) {
		this.percentageChange = percentageChange;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", manager=" + manager
				+ ", noOfStocks=" + noOfStocks + ", stockPrice=" + stockPrice + ", percentageChange=" + percentageChange
				+ "]";
	}
}