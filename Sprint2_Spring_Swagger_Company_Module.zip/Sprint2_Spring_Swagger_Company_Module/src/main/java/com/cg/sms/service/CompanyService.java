package com.cg.sms.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sms.dto.Company;
import com.cg.sms.exceptions.InvalidOperation;
import com.cg.sms.repository.CompanyRepository;
import com.cg.sms.validations.Validations;

@Service
public class CompanyService implements ICompanyService
{
	Logger logger = LoggerFactory.getLogger(CompanyService.class);
	
	@Autowired
	CompanyRepository compRepository;

	/***************************Add Company Details***********************************/
	
	public Company addCompanyInfo(Company info) throws InvalidOperation 
	{
		logger.info("add company info started execution");
		if((info!=null)&&(Validations.name(info.getCompanyName())) && (Validations.name(info.getManager().getManagerName())) && 
		   (Validations.email(info.getManager().getEmail())) && (Validations.mobileNo(info.getManager().getMobileNo())) &&
		   (info.getNoOfStocks()>=0) &&(info.getPercentageChange()>=0) &&(info.getStockPrice()>=0))
		{
			logger.info("company details are valid");
			return compRepository.save(info);
		}
		else
		{
			logger.info("company details are not valid");
			throw new InvalidOperation("Company details are not valid");
		}
	}
	
	/***************************Get All Company Details*********************************/
	
	public List<Company> getAllCompanyInfo() 
	{
		logger.info("get all company info started execution");
		return compRepository.findAll();
	}
	
	/************************Get Company Details Based On Id*****************************/
	
	public Company getCompanyDetails(int companyId)
	{
		logger.info("get company details started execution");
		Optional<Company> company=compRepository.findById(companyId);
		logger.info("searching for id");
		if(company.isPresent())
		{
			logger.info("id present/found");
			return company.get();
		}
		else
		{
			logger.info("id not found");
			try 
			{
				throw new InvalidOperation("No Company details found with given id");
			}
			catch(InvalidOperation e) {
				logger.info(e+"");
			}
			return company.get();
		}
	}

	/***************************Update Company Details***********************************/
	
	public Company updateCompanyInfo(Company info) throws InvalidOperation 
	{
		logger.info("update company info started execution");
		if((info!=null)&&(Validations.name(info.getCompanyName())) && (Validations.name(info.getManager().getManagerName())) && 
			(Validations.email(info.getManager().getEmail())) && (Validations.mobileNo(info.getManager().getMobileNo())) &&
			(info.getNoOfStocks()>=0) &&(info.getPercentageChange()>=0) &&(info.getStockPrice()>=0))
		{
			logger.info("company details are valid");
			return compRepository.save(info);
		}
		else
		{
			logger.info("company details are not valid");
			throw new InvalidOperation("Company details are not valid");
		}
	}
	
	/***************************Delete Company Details***********************************/
	
	public Company deleteCompanyInfo(int companyId) 
	{
		logger.info("delete company info started execution");
		Optional<Company> company=compRepository.findById(companyId);
		logger.info("searching for id");
		if(company.isPresent())
		{
			compRepository.deleteById(companyId);
			logger.info("id present/found");
			return company.get();
		}
		else
		{
			logger.info("id not found");
			try 
			{
				throw new InvalidOperation("No Company found with given id");
			}
			catch(InvalidOperation e)
			{
				logger.info(e+"");
			}
			return company.get();
		}
	}
}