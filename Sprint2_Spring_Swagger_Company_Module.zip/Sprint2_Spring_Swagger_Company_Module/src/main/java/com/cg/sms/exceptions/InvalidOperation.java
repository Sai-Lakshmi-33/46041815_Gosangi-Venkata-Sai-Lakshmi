package com.cg.sms.exceptions;

public class InvalidOperation extends Exception
{
	public String message;
	public InvalidOperation(String message)
	{
		this.message=message;
	}
	
	@Override
	public String toString()
	{
		return message;
	}
}