package com.cg.sms;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cg.sms.controller.CompanyController;
import com.cg.sms.dto.Company;
import com.cg.sms.dto.Manager;
import com.cg.sms.exceptions.InvalidOperation;
import com.cg.sms.service.CompanyService;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class ApplicationTest 
{
	@Mock
	CompanyService compService;
	
	@InjectMocks
    CompanyController compController;
   
	/*-------------------------Add Company Details Test-----------------------------------*/
    @Test
	public void addCompanyInfoTest()
    {
    	Company company=new Company(1,"intel",new Manager(2,"sai","sai@gmail.com","8796541234"),20,5000,2);
    	Company company1=new Company(3,"nestle",new Manager(4,"lakshmi","lakshmi@gmail.com","9834512783"),10,6000,1);
    	try {
			Mockito.when(compService.addCompanyInfo(company)).thenReturn(company);
		} 
    	catch (InvalidOperation e) {
			e.printStackTrace();
		}
		assertEquals(new ResponseEntity<>(company,HttpStatus.OK),compController.addCompanyInfo(company));
		assertNotEquals(new ResponseEntity<>(company,HttpStatus.BAD_REQUEST),compController.addCompanyInfo(company));
		assertNotEquals(new ResponseEntity<>(company,HttpStatus.OK),compController.addCompanyInfo(company1));
		assertNotNull(compController.addCompanyInfo(company1));
    }
    
    /*-----------------------Get All Company Details Test-------------------------------*/
    @Test
    public void getAllCompanyInfoTest()
    {
    	List<Company> list=new ArrayList<>();
    	list.add(new Company(1,"intel",new Manager(2,"sai","sai@gmail.com","8796541234"),20,5000,2));
		Mockito.when(compService.getAllCompanyInfo()).thenReturn(list);
		assertEquals(list,compController.getAllCompanyInfo());
		assertNotNull(list);
		assertTrue(list.size()>=0);
    }
    
    /*---------------------Get Company Details Based On Id Test---------------------------*/
    @Test
	public void getCompanyDetailsTest()
    {
    	Company company=new Company(1,"intel",new Manager(2,"sai","sai@gmail.com","8796541234"),20,5000,2);
    	Company company1=new Company(3,"nestle",new Manager(4,"lakshmi","lakshmi@gmail.com","9834512783"),10,6000,1);
		
    	Mockito.when(compService.getCompanyDetails(company.getCompanyId())).thenReturn(company);
		assertEquals(company,compController.getCompanyDetails(company.getCompanyId()));
		assertNotEquals(company,compController.getCompanyDetails(company1.getCompanyId()));
		assertNotNull(compController.getCompanyDetails(company.getCompanyId()));
	}
    
    /*-------------------------Update Company Details Test-------------------------------*/
    @Test
	public void updateCompanyInfoTest()
    {
    	Company company=new Company(1,"intel",new Manager(2,"sailakshmi","sai@gmail.com","6541234879"),10,2000,2);
    	Company company1=new Company(3,"nestle",new Manager(4,"lakshmi","lakshmi@gmail.com","9834512783"),10,6000,1);
    	try {
			Mockito.when(compService.updateCompanyInfo(company)).thenReturn(company);
		} 
    	catch (InvalidOperation e) {
			e.printStackTrace();
		}
		assertEquals(new ResponseEntity<>(company,HttpStatus.OK),compController.updateCompanyInfo(company));
		assertNotEquals(new ResponseEntity<>(company,HttpStatus.BAD_REQUEST),compController.updateCompanyInfo(company));
		assertNotEquals(new ResponseEntity<>(company,HttpStatus.OK),compController.updateCompanyInfo(company1));
		assertNotNull(compController.addCompanyInfo(company1));
	}
    
    /*-------------------------Delete Company Details Test--------------------------------*/
    @Test
	public void deleteCompanyInfoTest()
    {
    	Company company=new Company(1,"intel",new Manager(2,"sai","sai@gmail.com","8796541234"),20,5000,2);
		Mockito.when(compService.deleteCompanyInfo(company.getCompanyId())).thenReturn(company);
		assertEquals(company,compController.deleteCompanyInfo(company.getCompanyId()));
		assertNotNull(compController.deleteCompanyInfo(company.getCompanyId()));
	}
}